﻿/******************************************************************************
 * Copyright (c) 2014 Game Loop
 * All Rights reserved.
 *****************************************************************************/

using System;
using System.Collections.ObjectModel;
using System.Speech.Synthesis;

namespace EasyVoiceWinConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("ERROR");
                Console.WriteLine("NO ARGUMENTS");
                Console.WriteLine("");
                Console.WriteLine("This is a Windows application meant to run with Easy Voice Unity plugin");
                //Console.ReadLine();
                return;
            }

            string command = args[0];

            if (command == "makeFile")
            {
                try
                {
                    MakeFile(args);
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERROR");
                    Console.WriteLine("MAKE FILE");
                    Console.WriteLine(e);
                }
            }
            else if (command == "voiceList")
            {
                try
                {
                    MakeVoiceList(args);
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERROR");
                    Console.WriteLine("VOICE LIST");
                    Console.WriteLine(e);
                }
            }
        }

        private static void MakeVoiceList(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("ERROR");
                Console.WriteLine("NOT ENOUGH ARGUMENTS");
                //Console.ReadLine();
                return;
            }

            Console.WriteLine("VOICE LIST");
            SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();
            ReadOnlyCollection<InstalledVoice> installedVoices = speechSynthesizer.GetInstalledVoices();
            Console.WriteLine(installedVoices.Count);
            foreach (InstalledVoice installedVoice in installedVoices)
            {
                Console.WriteLine(installedVoice.VoiceInfo.Name);
                Console.WriteLine(installedVoice.VoiceInfo.Description);
                Console.WriteLine(installedVoice.VoiceInfo.Gender); // NotSet, Male, Female, Neutral
                Console.WriteLine(installedVoice.VoiceInfo.Age); // NotSet = 0, Child = 10, Teen = 15, Adult = 30, Senior = 65
            }

            //string fileName = args[1];
            //
            //Console.WriteLine("Saving voice info...");
            //FileStream fileStream = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            //StreamWriter streamWriter = new StreamWriter(fileStream, Encoding.Unicode);
            //SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();
            //ReadOnlyCollection<InstalledVoice> installedVoices = speechSynthesizer.GetInstalledVoices();
            //streamWriter.WriteLine("Windows");
            //streamWriter.WriteLine("v1");
            //streamWriter.WriteLine(installedVoices.Count);
            //foreach (InstalledVoice installedVoice in installedVoices)
            //{
            //    Console.WriteLine("Available voice: " + installedVoice.VoiceInfo.Name);
            //    streamWriter.WriteLine(installedVoice.VoiceInfo.Name);
            //}
            //streamWriter.Close();
            //fileStream.Close();
            //Console.WriteLine("Done.");
            //Console.ReadLine();
        }

        private static void MakeFile(string[] args)
        {
            if (args.Length < 4)
            {
                Console.WriteLine("ERROR");
                Console.WriteLine("NOT ENOUGH ARGUMENTS");
                //Console.ReadLine();
                return;
            }

            Console.WriteLine("FILE MAKE");

            string speechText = args[1];
            string speakerName = args[2];
            string fileName = args[3];
            //if (!fileName.EndsWith(".wav")) fileName += ".wav";

            SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();
            if (speakerName != "")
            {
                foreach (InstalledVoice installedVoice in speechSynthesizer.GetInstalledVoices())
                {
                    if (installedVoice.VoiceInfo.Name == speakerName)
                    {
                        speechSynthesizer.SelectVoice(speakerName);
                        break;
                    }
                }
            }
            speechSynthesizer.SetOutputToWaveFile(fileName);
            speechSynthesizer.Speak(speechText);
            Console.WriteLine("OKAY");
            Console.WriteLine(fileName);
            //Console.ReadLine();
        }
    }
}
