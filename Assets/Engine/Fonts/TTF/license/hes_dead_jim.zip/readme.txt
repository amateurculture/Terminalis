James's Fonts

Fonts are cool. If you like fonts, you've probably thought at one time or
another, "I wish I could design a font". That's how this page came about.
These are fonts I've designed.

You are free to use them, although I'd appreciate it if you'd send me an
email telling me what you did with them. You may distribute them providing
you include the readme file and don't chage any money for doing so. You may
not include the fonts on a commercial CD Rom without my permission. All fonts
on this page are the copyright property of James Shields.

I started designing some simple fonts in Corel Draw 3, years ago, but it was
too much like hard work. It's an excellent program, it's just not a font
designer.

The later fonts are designed with Softy, the only Shareware TrueType font
designer I know of. It's a bit basic, but it's an excellent piece of
shareware, and can produce some excellent results if you're persistent.

If you like this font, please write and let me know. My email address is
"jshields@iol.ie".

You can find more of my fonts at "http://www.iol.ie/~jshields/fonts.html".